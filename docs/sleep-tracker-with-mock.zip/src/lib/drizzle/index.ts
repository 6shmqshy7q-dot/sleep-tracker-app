import { drizzle } from 'drizzle-orm/neon-http';
import { neon } from '@neondatabase/serverless';

// Disable SSL verification for development
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

// Check if we have a valid database URL
const hasDbUrl = process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('localhost');

// Use mock data if no real database
let drizzleDb: any;

if (hasDbUrl) {
  const sql = neon(process.env.DATABASE_URL!);
  drizzleDb = drizzle(sql);
} else {
  console.log('⚠️ No database configured, using mock data for demo');
  // Mock database for demo purposes
  drizzleDb = {
    insert: () => ({
      values: () => ({
        returning: () => Promise.resolve([{ id: 1, email: 'demo@example.com', username: 'demo' }])
      })
    }),
    select: () => ({
      from: () => ({
        where: () => ({
          limit: () => Promise.resolve([])
        }),
        orderBy: () => Promise.resolve([])
      })
    })
  };
}

export { drizzleDb };
