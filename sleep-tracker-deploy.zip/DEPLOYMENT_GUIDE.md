# 🚀 Sleep Tracker 部署指南 - GitHub + Vercel

## 步骤 1：创建 GitHub 仓库

1. 访问 [GitHub.com](https://github.com) 并登录
2. 点击右上角 **"+"** 按钮
3. 选择 **"New repository"**
4. 仓库设置：
   - **Repository name**: `sleep-tracker-app` （或您喜欢的名字）
   - **Description**: `Sleep tracking app with Drizzle ORM and Neon Database`
   - **Visibility**: 选择 "Public" 或 "Private"
   - ✅ 勾选 "Add a README file"
   - ✅ 勾选 "Add .gitignore" → 选择 "Node"
5. 点击 **"Create repository"**

## 步骤 2：推送代码

在终端中运行以下命令（替换您的用户名和仓库名）：

```bash
# 添加远程仓库（替换 YOUR_USERNAME 和 YOUR_REPO_NAME）
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git

# 重命名分支为 main
git branch -M main

# 推送到 GitHub
git push -u origin main
```

## 步骤 3：连接 Vercel

1. 访问 [Vercel.com](https://vercel.com) 并登录
2. 点击 **"New Project"**
3. 选择 **"Import Git Repository"**
4. 选择您的 GitHub 仓库
5. 点击 **"Import"**

## 步骤 4：配置环境变量

在 Vercel 项目设置页面：

1. 进入 **Settings** → **Environment Variables**
2. 添加以下变量：

```
DATABASE_URL = postgresql://user:pass@localhost/db?sslmode=require
NEXTAUTH_SECRET = your-secret-key-here
NEXTAUTH_URL = https://your-app.vercel.app
```

⚠️ **注意**：
- `DATABASE_URL` 需要使用真实的 Neon 数据库 URL
- `NEXTAUTH_SECRET` 可以是任意随机字符串
- `NEXTAUTH_URL` 部署后会自动设置

## 步骤 5：部署

1. 在 Vercel 项目页面，点击 **"Deploy"**
2. 等待构建完成（通常需要 2-3 分钟）
3. 完成后会显示部署 URL

## 步骤 6：验证

✅ 访问部署的 URL
✅ 测试网站功能
✅ 检查所有页面是否正常加载

## 🎉 完成！

恭喜！您的 Sleep Tracker 应用已成功部署！

---

**需要帮助？**
- Vercel 文档：https://vercel.com/docs
- GitHub 文档：https://docs.github.com
